// 获取属性的状态
export const getMenuItems = state => state.menuItems
export const currentUser = state => state.currentUser
export const isLogin = state => state.isLogin