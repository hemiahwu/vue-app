<template>
  <h1>米斯特吴</h1>
</template>
