<template>
  <div class="card text-dark bg-light mb-3">
    <div class="card-header">点餐文档</div>
    <div class="card-body">
      <h4 class="card-title">点餐文档</h4>
      <p class="card-text">27732357@qq.com</p>
    </div>
  </div>
</template>
