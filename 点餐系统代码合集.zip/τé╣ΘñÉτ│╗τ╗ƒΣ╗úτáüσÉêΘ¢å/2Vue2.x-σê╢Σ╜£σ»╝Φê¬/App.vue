<template>
  <div id="app">
    <div class="container">
      <app-header></app-header>
    </div>
  </div>
</template>

<script>
import Header from './components/Header';
export default {
  components:{
    appHeader:Header
  }
}
</script>

<style>

</style>
