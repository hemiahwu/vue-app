<template>
  <h1>Admin</h1>
</template>
